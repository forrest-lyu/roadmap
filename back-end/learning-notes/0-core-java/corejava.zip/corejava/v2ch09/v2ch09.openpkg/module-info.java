@SuppressWarnings("module")
module v2ch09.openpkg 
{
   requires com.horstmann.util;
   opens com.horstmann.places to com.horstmann.util;
}
